#pragma once

#include "glm.hpp"
#include "gtc\matrix_transform.hpp"
#include "gtc\type_ptr.hpp"

#include <vector>


using namespace glm;
using namespace std;

class Vehicle {

public:

	//points for the path to follow
	vector<vec3> pathPoints;
//start and end of the path to follow
	vec3 start;
	vec3 end;
	//radius of the path
	float radius;

	vec3 location;
	vec3 velocity;
	vec3 acceleration;

	float r;
	float wanderTheta;
	float maxForce;
	float maxSpeed;



	//Vehicle(float x, float y);

	void initialiseVehicle(float x, float y);

	void UpdateAi();

	void applyForce(vec3 *force);

	void seek(vec3 *target);

	void pursue();

	void wander();

	void arrive(vec3 *target);
	
	void containment();

	void pathFollow();

	void wallFollow();

};
