#pragma once
#include "vechicle.h"



class path : public Vehicle {


public:


	//starting point of the path
	vec3 start;
	//ending point of the path
	vec3 end;

	float radius;

	void pathInit();

private:




};