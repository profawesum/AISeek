#pragma once


class Input {

public:

	static void keyboardDown(unsigned char key, int x, int y);
	static void keyboardUp(unsigned char key, int x, int y);
	bool menuUpdate(int key);
	void processInput(double tempTime);

private:

	bool keyPushedW;
	bool keyPushedS;
	bool keyPushedA;
	bool keyPushedD;
	bool keyPushed;

};