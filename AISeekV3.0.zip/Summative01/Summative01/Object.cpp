
//local includes
#include "Object.h"
#include "TextureLoad.h"
#include "ShaderLoader.h"
#include "Camera.h"

#include "glm.hpp"
#include "gtc\matrix_transform.hpp"
#include "gtc\type_ptr.hpp"



using namespace std;

Camera camO;
LoadTexture ltO;

vec3 enemyPosition = vec3(-800.0f, -800.0f, 0.0f);
mat4 model2;

//creates matrices for the enemy
mat4 Object::matrixCreationEnemy(){

	//position matrix
	mat4 translationMatrix = translate(mat4(), enemyPosition);

	//rotation matrix
	/*vec3 rotationAxisZ = vec3(0.0f, 0.0f, 1.0f);
	float rotationAngle = 0;
	mat4 rotationZ = rotate(mat4(), radians(rotationAngle), rotationAxisZ);
*/
	//scale matrix
	vec3 objScale = vec3(150.0f, 150.0f, 150.0f);
	mat4 scaleMatrix = scale(mat4(), objScale);
	//model matrix	

	model2 = translationMatrix * scaleMatrix;
;
	
	return model2;
}

//create an enemy
void Object::createEnemy(){

	program = ShaderLoader::CreateProgram("Resources/Shaders/enemyShader.vs", "Resources/Shaders/enemyShader.fs");

#pragma region "Creating Buffers for Enemy"
		glUseProgram(program);

		glGenVertexArrays(1, &VAO);
		glBindVertexArray(VAO);

		//element buffer
		glGenBuffers(1, &EBO);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices3), indices3, GL_STATIC_DRAW);

		glGenBuffers(1, &VBO);
		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferData(GL_ARRAY_BUFFER, sizeof(vertices2), vertices2, GL_STATIC_DRAW);

#pragma endregion

#pragma region "Enabling Buffers for Enemy"

		glVertexAttribPointer(6, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)0);
		glEnableVertexAttribArray(6);

		glVertexAttribPointer(7, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
		glEnableVertexAttribArray(7);

		glVertexAttribPointer(8, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
		glEnableVertexAttribArray(8);

		//glActiveTexture(GL_TEXTURE4);
		//glBindTexture(GL_TEXTURE_2D, ltO.loadTexture("Resources/Textures/meteorBig.png"));
		//glUniform1i(glGetUniformLocation(program, "tex"), 4);


		GLuint viewLoc = glGetUniformLocation(program, "view");
		glUniformMatrix4fv(viewLoc, 1, GL_FALSE, value_ptr(camO.initalise(true)));

		//projection
		GLuint projLoc = glGetUniformLocation(program, "proj");
		glUniformMatrix4fv(projLoc, 1, GL_FALSE, value_ptr(camO.initalise(false)));

		glBindVertexArray(0); // unbind VAO

		glUseProgram(0);

#pragma endregion

}

//renders the enemy
void Object::renderObject(){

	glUseProgram(program);

	glActiveTexture(GL_TEXTURE4);
	glBindTexture(GL_TEXTURE_2D, ltO.loadTexture("Resources/Textures/meteorBig.png"));
	glUniform1i(glGetUniformLocation(program, "tex"), 4);

	//matrix rotation, position and scale
	GLuint modelLoc = glGetUniformLocation(program, "model");
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, value_ptr(matrixCreationEnemy()));

	glBindVertexArray(VAO);
	glDrawElements(GL_TRIANGLES, sizeof(vertices3), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0); // unbind VAO

	glUseProgram(0);

}

//check to see if there is a colision between players and enemies
bool Object::collisionTrigger(){

	//collision using aabb
	if ((camO.getObjPosX() / 150) < enemyPosition.x + 0.4 && (camO.getObjPosX() / 150) + 0.2 > enemyPosition.x 
		&& (camO.getObjPosY() / 150) < enemyPosition.y + 0.2 && (camO.getObjPosY() / 150) + 0.2 > enemyPosition.y) {
		return true;
	}
	else {
		return false;
	}
}


//getter and setter functions

vec3 Object::getEnemyPos(){
	return enemyPosition;
}

vec3 Object::setEnemyPosY(float newObjPos){
	enemyPosition.y = newObjPos;
	return enemyPosition;
}

vec3 Object::setEnemyPosX(float newObjPos){
	enemyPosition.x = newObjPos;
	return enemyPosition;
}

vec3 Object::setEnemyPos(vec3 pos){
	enemyPosition = pos;
	return enemyPosition;
}

float Object::getEnemyPosX(){
	return enemyPosition.x;
}

float Object::getEnemyPosY(){
	return enemyPosition.y;
}
