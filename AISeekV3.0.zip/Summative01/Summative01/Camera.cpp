#include <iostream>
#include <glew.h>
#include <freeglut.h>
#include <SOIL.h>
#include "ShaderLoader.h"
#include "TextureLoad.h"
#include "Audio.h"
#include "Input.h"
#include "Utils.h"
#include "TextLabel.h"
#include "Camera.h"


#include "glm.hpp"
#include "gtc\matrix_transform.hpp"
#include "gtc\type_ptr.hpp"

using namespace std;
using namespace glm;

vec3 camPos = vec3(0.0f, 0.0f, 3.0f);
vec3 camLookDir = vec3(0.0f, 0.0f, -1.0f);
vec3 camUpDir = vec3(0.0f, 1.0f, 0.0f);
vec3 playerPostition = vec3(400.0f, 250.0f, 0.0f);
mat4 view;
mat4 proj;
mat4 model;


mat4 Camera::initalise(bool view1){
	view = lookAt(camPos, camPos + camLookDir, camUpDir);
	//perspective camera
	//proj = perspective(45.0f, (float)Utils::SCR_WIDTH / (float)Utils::SCR_HEIGHT, 0.1f, 100.0f);


	//orthographic camera
	float halfScreenWidth = (float)Utils::SCR_WIDTH *0.5f;
	float halfScreenHeight = (float)Utils::SCR_HEIGHT *0.5f;

	proj = ortho(-halfScreenWidth, halfScreenWidth, -halfScreenHeight, halfScreenHeight, 0.1f, 100.0f);

	if (view1 == true) {
		return view;	
	}
	else {
		return proj;
	}
	
}

mat4 Camera::matrixCreation(){

	//position matrix
	
	mat4 translationMatrix = translate(mat4(), playerPostition);

	//rotation matrix
	vec3 rotationAxisZ = vec3(0.0f, 0.0f, 1.0f);
	float rotationAngle = 0;
	mat4 rotationZ = rotate(mat4(), radians(rotationAngle), rotationAxisZ);

	//scale matrix
	vec3 objScale = vec3(150.0f, 150.0f, 150.0f);
	mat4 scaleMatrix = scale(mat4(), objScale);

	//model matrix
	model = translationMatrix * rotationZ * scaleMatrix;

	return model;
}


vec3 Camera::getObjPos() {
	return playerPostition;
}

float Camera::getObjPosX() {
	return playerPostition.x;
}

float Camera::getObjPosY() {
	return playerPostition.y;
}

vec3 Camera::setObjPosY(vec3 newObjPos) {
	playerPostition.y = newObjPos.y;
	return playerPostition;
}

vec3 Camera::setObjPosX(vec3 newObjPos){
	playerPostition.x = newObjPos.x;
	return playerPostition;
}
