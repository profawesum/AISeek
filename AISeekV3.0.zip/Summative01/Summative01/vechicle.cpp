#include "vechicle.h"
#include "Object.h"
#include "GameManager.h"
#include "camera.h"

#include <iostream>
#include <limits>
#include <cmath>
#include <map>

#include "glm.hpp"
#include "gtc\matrix_transform.hpp"
#include "gtc\type_ptr.hpp"

Object objAI;
GameManager managerAi;
Camera camAI;

bool startFollow = true;
int timer = 0;

using namespace std;
using namespace glm;

//create the vehicle
void Vehicle::initialiseVehicle(float x, float y){

	//vector setup
	acceleration += (0, 0, 0);
	velocity += (0.0f, 0.0f, 0.0f);
	location += (x, y, 0);

	//other value setup
	r = 3.0f;
	maxSpeed = 0.5f;
	maxForce = 0.1f;

	//path following setup
	radius = 1.0f;

	wanderTheta = 0;

	//path points
	vec3 point1(-280.0f, 200.0f,0.0f);
	vec3 point2(-100.0f, 0.0f,0.0f);
	vec3 point3(150.0f, 200.0f,0.0f);
	vec3 point4(350.0f, 0.0f,0.0f);

	//putting the points into the vector
	pathPoints.push_back(point1);
	pathPoints.push_back(point2);
	pathPoints.push_back(point3);
	pathPoints.push_back(point4);

	/*start = vec3(-300.0f, -300.0f, 0.0f);
	end = vec3(150.0f, -300.0f, 0.0f);*/
}

//update the ai
void Vehicle::UpdateAi(){

	velocity += acceleration;

	if (velocity.x >= maxSpeed) {
		velocity.x = maxSpeed;
	}
	if (velocity.y >= maxSpeed) {
		velocity.y = maxSpeed;
	}
	location += velocity;
	acceleration * 0.0f;

	objAI.setEnemyPos(location);

}

//apply force to object
void Vehicle::applyForce(vec3 *force) {
	acceleration = acceleration = *force;
}

//seek a desired position/target
void Vehicle::seek(vec3 *target) {

	vec3 desired = (*target - location);
	
	desired = normalize(desired) *  maxSpeed;

	//calculate the steering force
	vec3 steer = (desired - velocity);
	//if the steering force is greater than the max force
	//make steering force = to maxForce
	if (steer.x >= maxForce) {
		steer.x = maxForce;
	}
	if (steer.y >= maxForce) {
		steer.y = maxForce;
	}
	//apply the steering force to the object
	applyForce(&steer);
	UpdateAi();

}

//ai wanders randomly
//random number chooses the direction to move towards
//it then seeks the random position that was chosen
void Vehicle::wander(){

	if (timer >= 150) {
		//set a random target and seek that target then move to another random position
		vec3 target = vec3(managerAi.randomNumber(), managerAi.randomNumber(), 0.0f);
		seek(&target);
		//reset the timer
		timer = 0;
	}
	//prevents it from going off the screen
	containment();
	//increments timer
	timer++;
	//moves the ai
	UpdateAi();
}

//Seeks the target then slows down as it gets
//closer to the target
void Vehicle::arrive(vec3 * target){

	vec3 desired = (*target - location);

	float distance = length(desired);

	desired = normalize(desired);

	//slows down if it is within a set range
	if (distance < 300) {
		//processings map function rewritten for c++
		float m = (distance) * ((maxSpeed) / (150.0f));
		//slows down desired
		desired = desired * m;
	}
	//if not in the set distance move at maxSpeed
	else {
		desired = desired * maxSpeed;
	}

	vec3 steer = (desired - velocity);

	//prevents steering force from being greater than maxForce
	if (steer.x >= maxForce) {
		steer.x = maxForce;
	}
	if (steer.y >= maxForce) {
		steer.y = maxForce;
	}
	//if the object is at the target point
	if (distance < 3) {
		return;
	}

	//apply the force and update the ai
	applyForce(&steer);
	UpdateAi();
}

//keeps the ai within the constrains of the screen
//or the wall effectivly bouncing off of the wall
//heading to the opposite direction
void Vehicle::containment(){

	velocity = vec3(maxSpeed, maxSpeed, 0.0f);

	//Upper wall
	if (objAI.getEnemyPosY() > 350.0f) {
		vec3 desired = vec3(maxSpeed, -velocity.y, 0.0f);
		vec3 steer = (desired - velocity);
		if (steer.x >= maxForce) {
			steer.x = maxForce;
		}
		if (steer.y >= maxForce) {
			steer.y = maxForce;
		}
		applyForce(&steer);
	}
	//Bottom wall
	if (objAI.getEnemyPosY() < -250.0f) {
		vec3 desired = vec3(-maxSpeed, velocity.y, 0.0f);// - 20.0f
		vec3 steer = (desired - velocity);
		////prevents steering force from being greater than maxForce
		if (steer.x >= maxForce) {
			steer.x = maxForce;
		}
		if (steer.y >= maxForce) {
			steer.y = maxForce;
		}
		applyForce(&steer);
	}

	//left wall
	if (objAI.getEnemyPosX() < -300.0f) {
		vec3 desired = vec3(velocity.x, maxSpeed , 0.0f);//+ 10.0f
		vec3 steer = (desired - velocity);

		////prevents steering force from being greater than maxForce
		if (steer.x >= maxForce) {
			steer.x = maxForce;
		}
		if (steer.y >= maxForce) {
			steer.y = maxForce;
		}
		applyForce(&steer);
	}

	//right wall
	if (objAI.getEnemyPosX() > 450.0f) {

		vec3 desired = -vec3(velocity.x, maxSpeed, 0.0f);// + 2.0f
		vec3 steer = (desired - velocity);

		////prevents steering force from being greater than maxForce
		if (steer.x >= maxForce) {
			steer.x = maxForce;
		}
		if (steer.y >= maxForce) {
			steer.y = maxForce;
		}
		applyForce(&steer);
	}
	UpdateAi();
}


//gets the normal point
vec3 getNormalPoint(vec3 p, vec3 a, vec3 b) {

	vec3 ap = p - a;
	vec3 ab = b - a;
	ab = normalize(ab);
	ab = ab * dot(ap, ab);
	vec3 normalPoint = a + ab;
	return normalPoint;
}

//the ai will follow a given path, if it leaves the path
//it will seek the path, coming into the nearest point it can 
void Vehicle::pathFollow(){

	if (startFollow == true) {
		location = vec3(-300.0f, 150.0f, 0.0f);
		
		startFollow = false;
	}

	cout << location.y << endl;

	velocity = vec3(maxSpeed, maxSpeed, 0.0f);
	// Predict position 50 (arbitrary choice) frames ahead
	// This could be based on speed 
	vec3 predict = velocity;
	predict = normalize(predict) * 50.0f;
	vec3 predictpos = location + predict;

	// Now we must find the normal to the path from the predicted position
	// We look at the normal for each line segment and pick out the closest one

	vec3 normal;
	vec3 target;
	float worldRecord = 1000000;  // Start with a very high record distance that can easily be beaten

								  // Loop through all points of the path
	for (int i = 0; i < pathPoints.size() - 1; i++) {

		// Look at a line segment
		vec3 a = pathPoints.at(i);
		vec3 b = pathPoints.at(i + 1);

		// Get the normal point to that line
		vec3 normalPoint = getNormalPoint(predictpos, a, b);
		// This only works because we know our path goes from left to right
		// We could have a more sophisticated test to tell if the point is in the line segment or not
		if (normalPoint.x < a.x || normalPoint.x > b.x) {
			// This is something of a hacky solution, but if it's not within the line segment
			// consider the normal to just be the end of the line segment (point b)
			normalPoint = b;
		}

		// How far away are we from the path?
		float dist = distance(predictpos, normalPoint);
		// Did we beat the record and find the closest line segment?
		if (dist < worldRecord) {
			worldRecord = dist;
			// If so the target we want to steer towards is the normal
			normal = normalPoint;

			// Look at the direction of the line segment so we can seek a little bit ahead of the normal
			vec3 dir = b - a;
			dir = normalize(dir) * 10.0f;
			target = normalPoint;
			target += dir;
		}
	}

	// Only if the distance is greater than the path's radius do we bother to steer
	if (worldRecord > radius) {
		seek(&target);
	}

#pragma region working
	//if (startFollow == true) {
	//	location = vec3(0.0f, 0.0f, 0.0f);
	//	velocity = vec3(maxSpeed, 0.0f, 0.0f);
	//	startFollow = false;
	//}

	//// Predict position 50 (arbitrary choice) frames ahead
	//vec3 predict = velocity;
	//predict = normalize(predict) * 50.0f;
	//vec3 predictpos = location + predict;

	//// Look at the line segment
	//vec3 a = start;
	//vec3 b = end;

	//// Get the normal point to that line
	//vec3 normalPoint = getNormalPoint(predictpos, a, b);

	//// Find target point a little further ahead of normal
	//vec3 dir = b - a;
	//dir = normalize(dir) * 10.0f;
	//
	//vec3 target = normalPoint + dir;

	//// How far away are we from the path?
	//float dist = length(predictpos + normalPoint);
	//// Only if the distance is greater than the path's radius do we bother to steer
	//if (dist > radius) {
	//	seek(&target);
	//}
#pragma endregion
}

//follows along the outside of the screen
//when it gets within a certain range of a wall
//procede to follow the next wall and continue in
//this fashion for the rest of the walls
void Vehicle::wallFollow(){

	if (startFollow == true) {
		location = vec3(0.0f, 300.0f, 0.0f);
		velocity = vec3(0.1f, 0.0f, 0.0f);
		startFollow = false;
	}

	
	cout << objAI.getEnemyPosX() << endl;

	//stops the enemy leaving the screen
	if (objAI.getEnemyPosY() >= 300.0f) {
		objAI.setEnemyPosY(300.0f);
		vec3 desired(velocity.x, 0.0f, 0.0f);
		vec3 steer = (desired - velocity);
		if (steer.x >= maxForce) {
			steer.x = maxForce;
		}
		if (steer.y >= maxForce) {
			steer.y = maxForce;
		}
		applyForce(&steer);
		//hits right wall moves down
		if (objAI.getEnemyPosX() >= 400.0f) {
			vec3 desired(0.0f, -velocity.y, 0.0f);
			vec3 steer = (desired - velocity);
			if (steer.x >= maxForce) {
				steer.x = maxForce;
			}
			if (steer.y >= maxForce) {
				steer.y = maxForce;
			}
			applyForce(&steer);
		}
		//if the ai hits the left wall walk up
		if (objAI.getEnemyPosX() <= -250.f) {
			vec3 desired(velocity.x, 0.0f, 0.0f);
			vec3 steer = (desired - velocity);
			if (steer.x >= maxForce) {
				steer.x = maxForce;
			}
			if (steer.y >= maxForce) {
				steer.y = maxForce;
			}
			applyForce(&steer);
		}
	}

	//stops the enemy leaving the screen
	if (objAI.getEnemyPosY() < -200.f) {
		objAI.setEnemyPosY(-200.f);
		//moves left when hits floor
		if (objAI.getEnemyPosX() >= 400.0f) {
			vec3 desired(-velocity.x, 0.0f, 0.0f);
			vec3 steer = (desired - velocity);
			if (steer.x >= maxForce) {
				steer.x = maxForce;
			}
			if (steer.y >= maxForce) {
				steer.y = maxForce;
			}
			applyForce(&steer);
		}
		//if the ai hits the left wall walk up
		if (objAI.getEnemyPosX() <= -250.f) {
			vec3 desired(0.0f, velocity.y, 0.0f);
			vec3 steer = (desired - velocity);
			if (steer.x >= maxForce) {
				steer.x = maxForce;
			}
			if (steer.y >= maxForce) {
				steer.y = maxForce;
			}
			applyForce(&steer);
		}
	}
}

