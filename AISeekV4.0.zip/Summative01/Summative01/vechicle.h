#pragma once

#include "glm.hpp"
#include "gtc\matrix_transform.hpp"
#include "gtc\type_ptr.hpp"

#include "Object.h"

#include <vector>


using namespace glm;
using namespace std;

class Vehicle {

public:

	//points for the path to follow
	vector<vec3> pathPoints;

	//vector of vehicles in group
	vector<vec3> vehiclePos;


	//start and end of the path to follow
	vec3 start;
	vec3 end;
	//radius of the path
	float radius;

	vec3 location;
	vec3 location2;
	vec3 velocity;
	vec3 acceleration;

	float r;
	float maxForce;
	float maxSpeed;

	float wandertheta;

	Vehicle();

	void initialiseVehicle(float x, float y);

	void UpdateAi();

	void applyForce(vec3 force);

	void seek(vec3 *target, int temp);

	void leaderFollow();

	void wander();

	void arrive(vec3 *target);
	
	void containment();

	void pathFollow();

	void wallFollow();

	void separation();

};
