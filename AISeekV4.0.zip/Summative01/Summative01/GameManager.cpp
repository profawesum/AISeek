#include "GameManager.h"
#include <iostream>
#include <glew.h>
#include <freeglut.h>
#include <sstream>
#include <SOIL.h>
#include "ShaderLoader.h"
#include "TextureLoad.h"
#include "Audio.h"
#include "Input.h"
#include "Utils.h"
#include "TextLabel.h"
#include "Camera.h"
#include "Object.h"
#include "vechicle.h"

#include "glm.hpp"
#include "gtc\matrix_transform.hpp"
#include "gtc\type_ptr.hpp"

#include <stdio.h>      /* printf, scanf, puts, NULL */
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */

Vehicle vehicle;
Input inMan;
Utils utMan;
Object obMan;
Camera camMan;


vec3 target(400.0f, 250.0f, 0.0f);


using namespace std;

void GameManager :: moveEnemy() {

}

int GameManager::randomNumber(){
	int randomNum = (rand() % (1 + 1-600)) + -300;
	return randomNum;
}



//runs through update
void GameManager::updateManager(){

	vec3 playerTarget = camMan.getObjPos();

	if (inMan.menuUpdate('1') == true) {
		//follow the player position
		vehicle.leaderFollow();
	}
	if (inMan.menuUpdate('2') == true) {
		vehicle.seek(&playerTarget, 1);
	}
	if (inMan.menuUpdate('3') == true) {
		vehicle.arrive(&playerTarget);
	}
	if (inMan.menuUpdate('4') == true) {
		vehicle.pathFollow();
	}
	if (inMan.menuUpdate('5') == true) {
		vehicle.wander();
	}
	if (inMan.menuUpdate('6') == true) {
		vehicle.containment();
	}
	//gets deltaTime
	deltaTime();
	//keyboard input passes through deltaTime value
	inMan.processInput(timeDelta);

	glutPostRedisplay();

}


//manages deltaTime
double GameManager::deltaTime(){

	time = glutGet(GLUT_ELAPSED_TIME);
	timeDelta = (time - oldTime)* 0.001f;
	oldTime = time;

	return timeDelta;

}

//initilze many things
void GameManager::initilise(){

	vehicle.initialiseVehicle(0,0);

	time = 0;
	timeDelta = 0;
	score = 0;
	oldTime = 0;

}



