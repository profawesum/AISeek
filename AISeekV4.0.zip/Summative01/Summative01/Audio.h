#pragma once


#include <fmod.hpp>


using namespace FMOD;

class Audio {



public:


	bool audioInit();
	void loadSound(int in);
	void playSound(Sound* clip);
	void destroy();
	void getSound(int in);

private:


	FMOD::System* audioSystem;
	FMOD::Sound* fxThump;
	FMOD::Sound* dejavu;
	FMOD::Sound* backOnTheRocks;
	FMOD::Sound* trackBackground;

protected:

};