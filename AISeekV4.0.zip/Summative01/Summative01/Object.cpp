
//local includes
#include "Object.h"
#include "TextureLoad.h"
#include "ShaderLoader.h"
#include "Camera.h"
#include "vechicle.h"

#include "glm.hpp"
#include "gtc\matrix_transform.hpp"
#include "gtc\type_ptr.hpp"



using namespace std;

Camera camO;
LoadTexture ltO;
GLuint enemy;
GLuint enemy1;
Vehicle vehicleObj;

vec3 enemyPosition = vec3(-0.0f, -0.0f, 0.0f);
vec3 enemyPosition2 = vec3(-100.0f, -100.0f, 0.0f);
mat4 model2;

//creates matrices for the enemy
mat4 Object::matrixCreationEnemy(vec3 enemyPos){

	//position matrix
	mat4 translationMatrix = translate(mat4(), enemyPos);

	//rotation matrix
	/*vec3 rotationAxisZ = vec3(0.0f, 0.0f, 1.0f);
	float rotationAngle = 0;
	mat4 rotationZ = rotate(mat4(), radians(rotationAngle), rotationAxisZ);
*/
	//scale matrix
	vec3 objScale = vec3(150.0f, 150.0f, 150.0f);
	mat4 scaleMatrix = scale(mat4(), objScale);
	//model matrix	

	model2 = translationMatrix * scaleMatrix;
	
	return model2;
}

//create an enemy
void Object::createEnemy(){

	program = ShaderLoader::CreateProgram("Resources/Shaders/enemyShader.vs", "Resources/Shaders/enemyShader.fs");

#pragma region "Creating Buffers for Enemy"
		glUseProgram(program);

		glGenVertexArrays(1, &VAO);
		glBindVertexArray(VAO);

		//element buffer
		glGenBuffers(1, &EBO);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices3), indices3, GL_STATIC_DRAW);

		glGenBuffers(1, &VBO);
		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferData(GL_ARRAY_BUFFER, sizeof(vertices2), vertices2, GL_STATIC_DRAW);

#pragma endregion

#pragma region "Enabling Buffers for Enemy"

		glVertexAttribPointer(6, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)0);
		glEnableVertexAttribArray(6);

		glVertexAttribPointer(7, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
		glEnableVertexAttribArray(7);

		glVertexAttribPointer(8, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
		glEnableVertexAttribArray(8);

		glActiveTexture(GL_TEXTURE3);
		enemy = ltO.loadTexture("Resources/Textures/meteorBig.png");
		glBindTexture(GL_TEXTURE_2D, enemy);
		glUniform1i(glGetUniformLocation(program, "tex"), 3);


		GLuint viewLoc = glGetUniformLocation(program, "view");
		glUniformMatrix4fv(viewLoc, 1, GL_FALSE, value_ptr(camO.initalise(true)));

		//projection
		GLuint projLoc = glGetUniformLocation(program, "proj");
		glUniformMatrix4fv(projLoc, 1, GL_FALSE, value_ptr(camO.initalise(false)));

		glBindVertexArray(0); // unbind VAO

		glUseProgram(0);
#pragma endregion

}

//create an enemy
void Object::createEnemy2() {

	program2 = ShaderLoader::CreateProgram("Resources/Shaders/enemyShader.vs", "Resources/Shaders/enemyShader.fs");

#pragma region "Creating Buffers for Enemy"
	glUseProgram(program2);

	glGenVertexArrays(1, &VAOe);
	glBindVertexArray(VAOe);

	//element buffer
	glGenBuffers(1, &EBOe);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBOe);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices3), indices3, GL_STATIC_DRAW);

	glGenBuffers(1, &VBOe);
	glBindBuffer(GL_ARRAY_BUFFER, VBOe);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices2), vertices2, GL_STATIC_DRAW);

#pragma endregion

#pragma region "Enabling Buffers for Enemy"

	glVertexAttribPointer(6, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(6);

	glVertexAttribPointer(7, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(7);

	glVertexAttribPointer(8, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(8);

	glActiveTexture(GL_TEXTURE4);
	enemy1 = ltO.loadTexture("Resources/Textures/player.png");
	glBindTexture(GL_TEXTURE_2D, enemy);
	glUniform1i(glGetUniformLocation(program2, "tex"), 4);


	GLuint viewLoc = glGetUniformLocation(program2, "view");
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, value_ptr(camO.initalise(true)));

	//projection
	GLuint projLoc = glGetUniformLocation(program2, "proj");
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, value_ptr(camO.initalise(false)));

	glBindVertexArray(0); // unbind VAO

	glUseProgram(0);
#pragma endregion

}

//renders the enemy
void Object::renderObject(){

	glUseProgram(program);
	glBindTexture(GL_TEXTURE_2D, enemy);
		
	//matrix rotation, position and scale
	GLuint modelLoc = glGetUniformLocation(program, "model");
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, value_ptr(matrixCreationEnemy(enemyPosition)));

	glBindVertexArray(VAO);
	glDrawElements(GL_TRIANGLES, sizeof(vertices3), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0); // unbind VAO

	glUseProgram(0);
}
//renders the enemy
void Object::renderObject2() {

	glUseProgram(program2);
	glBindTexture(GL_TEXTURE_2D, enemy1);

	//glActiveTexture(GL_TEXTURE4);
	////glBindTexture(GL_TEXTURE_2D, ltO.loadTexture("Resources/Textures/meteorBig.png"));
	//glUniform1i(glGetUniformLocation(program, "tex"), 4);

	//matrix rotation, position and scale
	GLuint modelLoc = glGetUniformLocation(program2, "model");
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, value_ptr(matrixCreationEnemy(enemyPosition2)));

	glBindVertexArray(VAOe);
	glDrawElements(GL_TRIANGLES, sizeof(vertices3), GL_UNSIGNED_INT, 0);
	glBindVertexArray(0); // unbind VAO

	cout << enemyPosition2.x << endl;

	glUseProgram(0);
}

//check to see if there is a colision between players and enemies
bool Object::collisionTrigger(){

	//collision using aabb
	if ((camO.getObjPosX() / 150) < enemyPosition.x + 0.4 && (camO.getObjPosX() / 150) + 0.2 > enemyPosition.x 
		&& (camO.getObjPosY() / 150) < enemyPosition.y + 0.2 && (camO.getObjPosY() / 150) + 0.2 > enemyPosition.y) {
		return true;
	}
	else {
		return false;
	}
}


//getter and setter functions

vec3 Object::getEnemyPos2() {
	return enemyPosition;
}

vec3 Object::setEnemyPos2(vec3 pos) {
	enemyPosition2 = pos;
	return enemyPosition2;
}



vec3 Object::getEnemyPos(){
	return enemyPosition;
}

vec3 Object::setEnemyPosY(float newObjPos){
	enemyPosition.y = newObjPos;
	return enemyPosition;
}

vec3 Object::setEnemyPosX(float newObjPos){
	enemyPosition.x = newObjPos;
	return enemyPosition;
}

vec3 Object::setEnemyPos(vec3 pos){
	enemyPosition = pos;
	return enemyPosition;
}

float Object::getEnemyPosX(){
	return enemyPosition.x;
}

float Object::getEnemyPosY(){
	return enemyPosition.y;
}
