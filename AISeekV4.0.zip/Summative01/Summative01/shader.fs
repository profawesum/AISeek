#version 330 core

in vec3 fragColor;
in vec2 fragTexCoord;

out vec4 color;


uniform float currentTime;
uniform sampler2D tex;
//uniform sampler2D tex1;

void main()
{
  
    //color = vec4(fragColor * abs(tan(currentTime)), 1.0);
	color = texture(tex, fragTexCoord);
	
	 //vec3 colorTemp = fragColor * abs(tan(currentTime));
    //color2 = mix(texture(tex, fragTexCoord2), texture(tex1, fragTexCoord2), 0.5f * abs(tan(currentTime)));

}