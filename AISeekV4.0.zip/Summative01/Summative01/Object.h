#pragma once

#include <glew.h>
#include <freeglut.h>

#include "glm.hpp"
#include "gtc\matrix_transform.hpp"
#include "gtc\type_ptr.hpp"

using namespace glm;

class Object {


public:

#pragma region "Enemy Coords, Vertices and Indices"

	GLuint indices3[6] = {

		0,1,2,	//first triangle
		0,2,3,	//second trangle
	};

	GLfloat vertices3[32]{

		//position				//colour
		-0.9f, 0.3f, 0.0f,		1.0f, 1.0f, 1.0f,	0.0f, 0.0f,	//top left 0
		-0.9f, -0.3f, 0.0f,		1.0f, 1.0f, 1.0f,	0.0f, 1.0f, // top right 1
		-0.5f, -0.3f, 0.0f,		1.0f, 0.0f, 1.0f,	1.0f, 1.0f,	//bottom right 3
		-0.5f, 0.3f, 0.0f,		1.0f, 1.0f, 1.0f,	1.0f, 0.0f, //bottom left 4

	};

#pragma endregion

#pragma region "Player Coords"

	GLuint indices2[6] = {

		0,1,2,	//first triangle
		0,2,3,	//second trangle
	};

	GLfloat vertices2[32]{

		//position				//colour
		-1.0f, 0.3f, 0.0f,		1.0f, 1.0f, 1.0f,	0.0f, 0.0f,	//top left 0
		-1.0f, -0.3f, 0.0f,		1.0f, 1.0f, 1.0f,	0.0f, 1.0f, // top right 1
		-0.2f, -0.3f, 0.0f,		1.0f, 0.0f, 1.0f,	1.0f, 1.0f,	//bottom right 3
		-0.2f, 0.3f, 0.0f,		1.0f, 1.0f, 1.0f,	1.0f, 0.0f, //bottom left 4

	};
#pragma endregion

	mat4 matrixCreationEnemy(vec3 enemyPos);

	void createEnemy();
	void renderObject();
	bool collisionTrigger();


	vec3 getEnemyPos();
	vec3 setEnemyPosY(float newObjPos);
	vec3 setEnemyPosX(float newObjPos);
	vec3 setEnemyPos(vec3 pos);


	void createEnemy2();
	void renderObject2();
	vec3 getEnemyPos2();
	vec3 setEnemyPos2(vec3 pos);

	float getEnemyPosX();
	float getEnemyPosY();

private:

	GLfloat enemyWidth = 0.1f;
	GLfloat enemyHeight = 0.1f;

	//for enemy
	GLuint VBO;
	GLuint VAO;
	GLuint EBO;
	GLuint program;

	GLuint VBOe;
	GLuint VAOe;
	GLuint EBOe;
	GLuint program2;

};