#include "vehicle.h"
#include "EnemyManager.h"

#include <iostream>


EnemyManager eMan;


//
////constructor
//Vehicle::Vehicle(float x, float y){
//
//	acceleration += (0, 0);
//	velocity += (0, 0);
//	location += (x, y);
//
//	r = 3.0f;
//	maxSpeed = 4.0f;
//	maxForce = 0.1f;
//
//}

void Vehicle::initialiseVehicle(float x, float y) {

	acceleration = vec3(0, 0, 0);
	velocity = vec3(0, 0, 0);
	location = vec3(x, y, 0);

	r = 3.0f;
	maxSpeed = 0.01f;
	maxForce = 0.001f;
}

void Vehicle::UpdateAi() {

	velocity += acceleration;

	if (velocity.x > maxSpeed) {
		velocity.x = maxSpeed;
	}
	if (velocity.y > maxSpeed) {
		velocity.y = maxSpeed;
	}
	location += velocity;

	eMan.SetEPos(location);

}

void Vehicle::applyForce(vec3 force) {

	acceleration += force;
	UpdateAi();

}

void Vehicle::seek(vec3 target) {

	vec3 desired = (target -= location);
	desired = normalize(desired);
	desired * maxSpeed;

	//calculate the steering force
	vec3 steer = (desired - velocity);
	//if the steering force is greater than the max force
	//make steering force = to maxForce
	if (steer.x > maxForce) {
		steer.x = maxForce;
	}
	if (steer.y > maxForce) {
		steer.y = maxForce;
	}
	//apply the steering force to the object
	applyForce(steer);

}