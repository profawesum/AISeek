#include "CubeMap.h"

#include <vector>;
#include <SOIL.h>

static GLuint LoadCubemap()
{

}