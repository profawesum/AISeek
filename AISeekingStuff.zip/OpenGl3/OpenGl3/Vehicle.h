#pragma once

#include "glm.hpp"
#include "gtc\matrix_transform.hpp"
#include "gtc\type_ptr.hpp"


using namespace glm;
using namespace std;

class Vehicle {

public:

	vec3 location;
	vec3 velocity;
	vec3 acceleration;

	float r;
	float maxForce;
	float maxSpeed;

	//Vehicle(float x, float y);

	void initialiseVehicle(float x, float y);

	void UpdateAi();

	void applyForce(vec3 force);

	void seek(vec3 target);

};
