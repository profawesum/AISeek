#include "Input.h"
#include "Camera.h"
#include "Audio.h"
#include "Utils.h"
#include "GameManager.h"
#include "Object.h"
#include <iostream>
using namespace std;

int num = 20;
int initDeltaTime = 0;

Camera camI;
Audio audI;
Utils utI;
GameManager gmI;
Object obI;

enum InputState {

	UP,
	DOWN,
	UP_FIRST,
	DOWN_FIRST,

};

InputState KeyState[255];

bool Input::menuUpdate(int key){

	if (KeyState[key] == DOWN)
	{
		return(true);
	}
	return(false);
}


//process Input
void Input::processInput(double deltaTime){

		if (KeyState['w'] == DOWN || KeyState['W'] == DOWN) {
			if (camI.getObjPosY() <= 340) {
				vec3 tempPos = camI.getObjPos();
				tempPos.y += (float)(400 * deltaTime);
				camI.setObjPosY(tempPos);
				audI.loadSound(3);
			}
		}
		if (KeyState['s'] == DOWN || KeyState['S'] == DOWN) {
			if (camI.getObjPosY() >= -330) {
				vec3 tempPos = camI.getObjPos();
				tempPos.y -= (float)(400 * deltaTime);
				camI.setObjPosY(tempPos);
			}
		}
		if (KeyState['a'] == DOWN || KeyState['A'] == DOWN) {
			if (camI.getObjPosX() >= -250) {
				vec3 tempPos = camI.getObjPos();
				tempPos.x -= (float)(400 * deltaTime);
				camI.setObjPosX(tempPos);
			}
		}
		if (KeyState['d'] == DOWN || KeyState['D'] == DOWN) {
			if (camI.getObjPosX() <= 430) {
				vec3 tempPos = camI.getObjPos();
				tempPos.x += (float)(400 * deltaTime);
				camI.setObjPosX(tempPos);
			}
		}
		if (KeyState['P'] == DOWN || KeyState['p'] == DOWN) {
			
		}
}


//Keyboard down input
void Input::keyboardDown(unsigned char key, int x, int y) {
	KeyState[key] = DOWN;
}

//Keyboard input up
void Input::keyboardUp(unsigned char key, int x, int y) {
	KeyState[key] = UP;
}


