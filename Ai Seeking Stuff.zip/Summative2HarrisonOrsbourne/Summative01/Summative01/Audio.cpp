
#include <fmod.hpp>
#include "Audio.h"
#include <iostream>


using namespace std;

//initialise audio manager
bool Audio::audioInit(){

	FMOD_RESULT result;
	result = FMOD::System_Create(&audioSystem);
	if (result != FMOD_OK) {
		return false;
	}


	result = audioSystem->init(100, FMOD_INIT_NORMAL | FMOD_INIT_3D_RIGHTHANDED, 0);
	if (result != FMOD_OK) {
		return false;
	}
	return true;
}

//loading sounds
void Audio::loadSound(int in){
	
	FMOD_RESULT result;
	//going to be used to load sounds
	if (in == 1) {
		result = audioSystem->createSound("Resources/Audio/dejavu.mp3", FMOD_DEFAULT, 0, &dejavu);
		getSound(1);
	}
	if (in == 2) {
		result = audioSystem->createSound("Resources/Audio/Thump.wav", FMOD_DEFAULT, 0, &fxThump);
		getSound(2);
	}
	if (in == 3) {
		result = audioSystem->createSound("Resources/Audio/backontherocks.mp3", FMOD_DEFAULT, 0, &backOnTheRocks);
		getSound(3);
	}
}


//used to play audio
void Audio::playSound(Sound* clip){

	FMOD_RESULT result;
	result = audioSystem->playSound(clip, 0, false, 0);

	audioSystem->update();

}

void Audio::destroy(){

	dejavu->release();
	fxThump->release();
	audioSystem->release();

}

//gets the sound that is required to play
void Audio::getSound(int in){

	if (in == 1) {
		playSound(dejavu);
	}
	if (in == 2) {
		playSound(fxThump);
	}
	if (in == 3) {
		playSound(backOnTheRocks);
	}
}






