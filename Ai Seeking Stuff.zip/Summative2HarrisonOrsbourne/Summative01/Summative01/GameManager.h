#pragma once

class GameManager {

public:

	double deltaTime();
	void initilise();
	void updateManager();
	void moveEnemy();

	bool start = false;
	bool gameOver = false;
	bool restart = false;
	float score = 0;

private:
	double time;
	double oldTime;
	double timeDelta;

};