#pragma once
#include "glm.hpp"
#include "gtc\matrix_transform.hpp"
#include "gtc\type_ptr.hpp"


using namespace glm;

class Camera {


public:

	//vec3 playerPostition;// = vec3(0.5f, 0.5f, 0.5f);

	mat4 initalise(bool view1);
	mat4 matrixCreation();
	vec3 getObjPos();
	vec3 setObjPosY(vec3 newObjPos);
	vec3 setObjPosX(vec3 newObjPos);

	float getObjPosX();
	float getObjPosY();

	float playerWidth = 0.2f;
	float playerHeight = 0.2f;



private:



protected:


};