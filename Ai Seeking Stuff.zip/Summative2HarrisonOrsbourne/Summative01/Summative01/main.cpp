#include <iostream>
#include <glew.h>
#include <sstream>
#include <freeglut.h>
#include <SOIL.h>
#include "ShaderLoader.h"
#include "TextureLoad.h"
#include "Audio.h"
#include "Input.h"
#include "Utils.h"
#include "TextLabel.h"
#include "Camera.h"
#include "GameManager.h"
#include "Object.h"

#include "glm.hpp"
#include "gtc\matrix_transform.hpp"
#include "gtc\type_ptr.hpp"

//#include "vld.h"


//namespace
using namespace std;
using namespace glm;




//shader stuff
ShaderLoader m_shader;
GLuint program = NULL;
GLuint program2 = NULL;

//references to other classes
LoadTexture lT;
Audio aud;
Input inM;
Utils utM;
Camera cam;
GameManager gmM;
Object obM;

#pragma region "VAO VBO EBO"

GLuint VBO;
GLuint VAO;
GLuint EBO;
GLuint VAO2;
GLuint VBO2;
GLuint EBO2;

#pragma endregion



#pragma region "Background Coords"

GLuint indices[] = {

	0,1,2,	//first triangle
	0,2,3,	//second trangle
};

GLfloat vertices[]{

	//position				//colour
	-1.0,  1.0f, 0.0f,		1.0f, 1.0f, 1.0f,	0.0f, 0.0f,	//top left 0
	-1.0f, -1.0f, 0.0f,		0.0f, 1.0f, 1.0f,	0.0f, 1.0f, // bottom left
	1.0f, -1.0f, 0.0f,		1.0f, 0.0f, 0.0f,	1.0f, 1.0f,	//bottom right 3
	1.0f,  1.0f, 0.0f,		1.0f, 1.0f, 0.0f,	1.0f, 0.0f, //bottom left 4

};


#pragma endregion

void Update() {

	if (inM.menuUpdate('p') == true) {
		gmM.start = true;
	}
	if (inM.menuUpdate('q') == true) {
		exit(0);
	}
	if (gmM.start == true) {
		gmM.updateManager();
	}

}


void Render() {

	if (gmM.start == false && gmM.gameOver == true) {
		textLabel label("Game Over", "Resources/Fonts/arial.ttf", glm::vec2(-300, 100));
		textLabel Score("Your Score was:" + (to_string(gmM.score)), "Resources/Fonts/arial.ttf", glm::vec2(-300, 0));
		textLabel restart("Press P to play again, Q to quit", "Resources/Fonts/arial.ttf", glm::vec2(-300, -100));
		label.textRender();
		Score.textRender();
		restart.textRender();
		gmM.initilise();
	}

	if (gmM.start == false && gmM.gameOver == false) {
#pragma region "Background rendering"

		glUseProgram(program);

		glBindVertexArray(VAO);
		glDrawElements(GL_TRIANGLES, sizeof(vertices), GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);

		glUseProgram(0);

#pragma endregion


		textLabel title("AI Summative 4", "Resources/Fonts/arial.ttf", glm::vec2(-300, 100));
		title.textRender();
		textLabel label("Press P to play/ Q to Quit", "Resources/Fonts/arial.ttf", glm::vec2(-300, 0));
		label.textRender();

	}

	if (gmM.start == true) {


		glClear(GL_COLOR_BUFFER_BIT);


#pragma region "Background rendering"

		glUseProgram(program);

		glBindVertexArray(VAO);
		glDrawElements(GL_TRIANGLES, sizeof(vertices), GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);

		glUseProgram(0);

#pragma endregion

#pragma region "Player Rendering"

		glUseProgram(program2);

		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, lT.loadTexture("Resources/Textures/player.png"));
		glUniform1i(glGetUniformLocation(program2, "tex"), 1);


#pragma region "matrix stuff"


		//matrix rotation, position and scale
		GLuint modelLoc = glGetUniformLocation(program2, "model");
		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, value_ptr(cam.matrixCreation()));

#pragma endregion

		glBindVertexArray(VAO2);
		glDrawElements(GL_TRIANGLES, sizeof(obM.vertices2), GL_UNSIGNED_INT, 0);
		glBindVertexArray(0); // unbind VAO

#pragma endregion

		glUseProgram(0);

		//render the enemy
		obM.renderObject();


		textLabel label("score:" + (to_string(gmM.score)), "Resources/Fonts/arial.ttf", glm::vec2(-120.0f, 340.0f));
		label.textRender();

		glUseProgram(0);

	

	}
	glutSwapBuffers();

}

//used when the program shuts down to fully stop everything
void ShutDown() {
	//destroy all the things
}

int main(int argc, char **argv) {

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(50, 50);
	glutInitWindowSize(utM.SCR_HEIGHT, utM.SCR_WIDTH);
	glutCreateWindow("Life is overated");

	if (glewInit() != GLEW_OK) {

		cout << " " << endl;
		system("pause");

	}

	glClearColor(0, 0,0, 1.0);

	program = ShaderLoader::CreateProgram("shader.vs", "shader.fs");
	program2 = ShaderLoader::CreateProgram("shader2.vs", "shader2.fs");

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	//enabling culling
	glCullFace(GL_BACK);
	glFrontFace(GL_CCW);
	glEnable(GL_CULL_FACE);


#pragma region "Creating buffers for Background"

	glUseProgram(program);

	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);

	//element buffer
	glGenBuffers(1, &EBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

	glGenBuffers(1, &VBO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(1);
	
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(2);
	
	glActiveTexture(GL_TEXTURE2);
	glBindTexture(GL_TEXTURE_2D, lT.loadTexture("Resources/Textures/Space.jpg"));
	glUniform1i(glGetUniformLocation(program, "tex"), 2);

	glBindVertexArray(0); // unbind VAO
#pragma endregion

#pragma region "Creating Buffers for Textured Quad"
	glGenVertexArrays(1, &VAO2);
	glBindVertexArray(VAO2);

	//element buffer
	glGenBuffers(1, &EBO2);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO2);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(obM.indices2), obM.indices2, GL_STATIC_DRAW);

	glGenBuffers(1, &VBO2);
	glBindBuffer(GL_ARRAY_BUFFER, VBO2);
	glBufferData(GL_ARRAY_BUFFER, sizeof(obM.vertices2), obM.vertices2, GL_STATIC_DRAW);

	glUseProgram(0);


#pragma endregion

#pragma region "Enabling Buffers for Textured Quad"

	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)0);
	glEnableVertexAttribArray(3);

	glVertexAttribPointer(4, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
	glEnableVertexAttribArray(4);

	glVertexAttribPointer(5, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat)));
	glEnableVertexAttribArray(5);

	glUseProgram(program2);

	GLuint viewLoc = glGetUniformLocation(program2, "view");
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, value_ptr(cam.initalise(true)));

	//projection
	GLuint projLoc = glGetUniformLocation(program2, "proj");
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, value_ptr(cam.initalise(false)));

	glUseProgram(0);
	glBindVertexArray(0); // unbind VAO

	

#pragma endregion

	gmM.initilise();

	obM.createEnemy();

	glutDisplayFunc(Render);
	glutIdleFunc(Update);

	//keyboard input
	glutKeyboardFunc(inM.keyboardDown);
	glutKeyboardUpFunc(inM.keyboardUp);

	//used to initialise audio
	//aud.audioInit();
	//load the background track
	aud.loadSound(1);

	glutMainLoop();

	return 0;
}