#include "GameManager.h"
#include <iostream>
#include <glew.h>
#include <freeglut.h>
#include <sstream>
#include <SOIL.h>
#include "ShaderLoader.h"
#include "TextureLoad.h"
#include "Audio.h"
#include "Input.h"
#include "Utils.h"
#include "TextLabel.h"
#include "Camera.h"
#include "Object.h"
#include "vechicle.h"


#include "glm.hpp"
#include "gtc\matrix_transform.hpp"
#include "gtc\type_ptr.hpp"


Vehicle vehicle;
Input inMan;
Utils utMan;
Object obMan;
Camera camMan;

vec3 target(0.2f, 1.0f, 0.0f);

using namespace std;

void GameManager :: moveEnemy() {

	//vehicle.seek(camMan.getObjPos());


	if (obMan.getEnemyPosX() >= 2.0) {
		float temp = 2.0;
		obMan.setEnemyPosX(temp);
	}

	if (obMan.getEnemyPosX() <= -2.0) {
		float temp = -1.5;
		obMan.setEnemyPosX(temp);
	}
	//vec3 tempX = obMan.getEnemyPos();
	//tempX.x += (float)(1 * timeDelta);
	//obMan.setEnemyPosX(tempX.x);

	//vec3 tempY = obMan.getEnemyPos();
	//tempY.y += (float)(1 * timeDelta);
	//obMan.setEnemyPosY(tempY.y);

	if (obMan.getEnemyPosY() >= 1.3) {
		obMan.setEnemyPosY(1.3f);
	}
	if (obMan.getEnemyPosY() <= -0.7) {
		obMan.setEnemyPosY(-0.7f);
		
	}


}


//runs through update
void GameManager::updateManager(){


		//follow the player position
		vehicle.seek(camMan.getObjPos());
		//gets deltaTime
		deltaTime();
		//keyboard input passes through deltaTime value
		inMan.processInput(timeDelta);
		//moves the enemies
		moveEnemy();


		////check if there is a collision
		//if (obMan.collisionTrigger() == true) {
		//	gameOver = true;
		//	start = false;
		//	oldTime = 0;
		//	timeDelta = 0;
		//}

		glutPostRedisplay();

}


//manages deltaTime
double GameManager::deltaTime(){

	time = glutGet(GLUT_ELAPSED_TIME);
	timeDelta = (time - oldTime)* 0.001f;
	oldTime = time;

	score += (float)(1 * timeDelta);

	return timeDelta;

}

void GameManager::initilise(){

	vehicle.initialiseVehicle(0,0);

	time = 0;
	timeDelta = 0;
	score = 0;
	oldTime = 0;

}



