#version 330 core

in vec3 fragColor2;
in vec2 fragTexCoord2;

out vec4 color2;


uniform float currentTime;
uniform sampler2D tex;

void main()
{
   
	 //vec3 colorTemp = fragColor * abs(tan(currentTime));
    //color2 = mix(texture(tex, fragTexCoord2), texture(tex1, fragTexCoord2), abs(sin(currentTime)));
	color2 = texture(tex, fragTexCoord2);

}