#pragma once



#include <iostream>
#include <glew.h>
#include <freeglut.h>
#include <SOIL.h>
#include "ShaderLoader.h"
#include "TextureLoad.h"
#include "Audio.h"
#include "Input.h"
#include "Utils.h"
#include "TextLabel.h"
#include "Camera.h"

#include "glm.hpp"
#include "gtc\matrix_transform.hpp"
#include "gtc\type_ptr.hpp"

class Utils {


public:

	float deltaTime;

	static const unsigned int SCR_WIDTH = 800;
	static const unsigned int SCR_HEIGHT = 800;

	GLfloat currentTime = 0;


	float oldTimeSinceStart = 0;
	float timeSinceStart;




private:






};